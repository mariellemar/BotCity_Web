#!/bin/bash

zip -r "BotCotacao.zip" * -x "BotCotacao.zip"